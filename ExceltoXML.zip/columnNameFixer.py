import csv
from collections import OrderedDict

with open("./sampleFiles/originalColumns.csv", "r", encoding='utf-8-sig') as originalColumns:
    newColumns = OrderedDict()
    reader = csv.reader(originalColumns)
    for row in reader:
        nextColumn = row[0]
        while nextColumn in newColumns:
            nextColumn = nextColumn + "1"

        newColumns[nextColumn] = True

print(newColumns)
with open("newColumns.csv", "w", encoding='utf-8-sig') as newColumnsFile:
    writer = csv.writer(newColumnsFile)
    for column in newColumns:
        writer.writerow([column])
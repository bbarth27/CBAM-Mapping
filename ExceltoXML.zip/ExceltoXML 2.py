import xmlschema
from dicttoxml2 import dicttoxml
from xml.dom.minidom import parseString
from collections import OrderedDict
import csv


def getDeclarant(row):
    declarant = OrderedDict()
    declarant['IdentificationNumber'] = row['Identification number']
    declarant['Name'] = row['Name']
    declarant['Role'] = row['Role']
    declarant['ActorAddress'] = getDeclarantActorAddress(row)
    return declarant


def getDeclarantActorAddress(row):
    actorAddress = OrderedDict()
    actorAddress['Country'] = row['Member State of establishment']
    actorAddress['City'] = row['City']
    return actorAddress


def getImporter(row):
    importer = OrderedDict()
    importer['IdentificationNumber'] = row['Identification number11']
    importer['Name'] = row['Name11']
    importer['ImporterAddress'] = getImporterActorAddress(row)
    return importer


def getImporterActorAddress(row):
    actorAddress = OrderedDict()
    actorAddress['Country'] = row['Member state or Country of establishment']
    actorAddress['City'] = row['City11']
    return actorAddress


def getSignatures(row):
    signatures = OrderedDict()
    signatures['ReportConfirmation'] = getSignatureRowConfirmation(row)
    applicableMethodologyConfirmation = OrderedDict()
    applicableMethodologyConfirmation['OtherApplicableReportingMethodology'] = row['Other applicable reporting methodology']
    signatures['ApplicableMethdologyConfirmation'] = applicableMethodologyConfirmation
    return signatures


def getSignatureRowConfirmation(row):
    confirmation = OrderedDict()
    confirmation['GlobalDataConfirmation'] = row['Report global data confirmation']
    confirmation['UseOfDataConfirmation'] = row['Use of data confirmation']
    confirmation['SignatureDate'] = row['Date of signature']
    confirmation['SignaturePlace'] = row['Place of signature']
    confirmation['Signature'] = row['Signature']
    confirmation['PositionOfPersonSending'] = row['Position of person signing']
    return confirmation


def getImportedGood(row):
    importedGood = OrderedDict()
    importedGood['ItemNumber'] = row['Goods item number']
    importedGood['CommodityCode'] = getCommodityCode(row)
    importedGood['OriginCountry'] = OrderedDict({"Country": row['Country code']})
    importedGood['ImportedQuantity'] = getImportedQuantity(row)
    importedGood['MeasureImported'] = OrderedDict(
        {"NetMass": row['Net mass1'],
         "MeasurementUnit": row['Type of measurement unit1']
         })
    importedGood['TotalEmissions'] = getTotalEmissions(row)
    importedGood["GoodsEmissions"] = getGoodsEmissions(row)

    return importedGood


def getCommodityCode(row):
    commodityCode = OrderedDict()
    commodityCode['HsCode'] = row[' Harmonized System sub-heading code']
    commodityCode['CnCode'] = row[' Combined nomenclature code']
    commodityDetails = OrderedDict()
    commodityDetails['Description'] = row[' Description of goods']
    commodityCode['CommodityDetails'] = commodityDetails
    return commodityCode


def getImportedQuantity(row):
    importedQuantity = OrderedDict()
    importedQuantity['SequenceNumber'] = row['Sequence number']
    importedQuantity['Procedure'] = OrderedDict({"RequestedProc": row['Requested procedure']})
    importedQuantity['ImportArea'] = OrderedDict({"ImportArea": row['Area of import']})
    importedQuantity['MeasureProcedureImported'] = OrderedDict(
        {"Indicator": row['Procedure indicator'],
         "NetMass": row['Net mass'],
         "MeasurementUnit": row['Type of measurement unit']
         })

    return importedQuantity


def getTotalEmissions(row):
    totalEmissions = OrderedDict()
    totalEmissions['EmissionsPerUnit'] = row['Goods emissions per unit of product']
    totalEmissions['OverallEmissions'] = row['Goods total emissions']
    totalEmissions['TotalDirect'] = row['Goods direct emissions']
    totalEmissions['TotalIndirect'] = row['Goods indirect emissions']
    totalEmissions['MeasurementUnit'] = row['Type of measurement unit for emissions']
    return totalEmissions


def getGoodsEmissions(row):
    goodsEmissions = OrderedDict()
    goodsEmissions['SequenceNumber'] = row['Emissions sequence number']
    goodsEmissions['ProductionCountry'] = row['Country of production']
    goodsEmissions['InstallationOperator'] = getInstallationOperators(row)
    goodsEmissions['ProducedMeasure'] = OrderedDict({
        "NetMass": row['Net mass11'],
        "MeasurementUnit": row['Type of measurement unit11']
    })
    goodsEmissions['InstallationEmissions'] = getInstallationEmissions(row)
    goodsEmissions['DirectEmissions'] = getDirectEmissions(row)
    goodsEmissions['IndirectEmissions'] = getIndirectEmissions(row)
    goodsEmissions['ProdMethodQualifyingParams'] = getProdQualifyingParams(row)

    return goodsEmissions


def getInstallationOperators(row):
    installationOperators = OrderedDict()
    installationOperators['OperatorId'] = row['Operator ID']
    installationOperators['OperatorName'] = row['Operator Name']
    installationOperators['OperatorAddress'] = getOperatorAddress(row)
    installationOperators['ContactDetails'] = getOperatorContactDetails(row)
    return installationOperators


def getOperatorContactDetails(row):
    contactDetails = OrderedDict()
    contactDetails['Name'] = row['Name11111']
    contactDetails['Phone'] = row['Phone number']
    contactDetails['Email'] = row['e-mail']
    return contactDetails


def getInstallationEmissions(row):
    installationEmissions = OrderedDict()
    installationEmissions['OverallEmissions'] = row['Installation total emissions']
    installationEmissions['TotalDirect'] = row['Installation direct emissions']
    installationEmissions['TotalIndirect'] = row['Installation indirect emissions']
    installationEmissions['MeasurementUnit'] = row['Type of measurement unit for emissions1']
    return installationEmissions


def getOperatorAddress(row):
    operatorAddress = OrderedDict()
    operatorAddress['Country'] = row['Country code1']
    operatorAddress['City'] = row['City11111']
    return operatorAddress


def getDirectEmissions(row):
    directEmissions = OrderedDict()
    directEmissions['DeterminationType'] = row['Type of determination']
    directEmissions['ApplicableReportingTypeMethodology'] = row['Type of applicable reporting methodology']
    directEmissions['MeasurementUnit'] = row['Type of measurement unit111']

    return directEmissions


def getIndirectEmissions(row):
    indirectEmissions = OrderedDict()
    indirectEmissions['DeterminationType'] = row['Type of determination1']
    indirectEmissions['SpecificEmbeddedEmissions'] = row['Specific (indirect) embedded emissions']
    indirectEmissions['MeasurementUnit'] = row['Type of measurement unit1111']
    indirectEmissions['ElectricitySource'] = row['Source of electricity']

    return indirectEmissions


def getProdQualifyingParams(row):
    prodQualifyingParams = OrderedDict()
    prodQualifyingParams['SequenceNumber'] = row['Sequence number11']
    prodQualifyingParams['MethodId'] = row['Method ID']
    prodQualifyingParams['MethodName'] = row['Method name']
    # prodQualifyingParams['DirectQualifyingParameters'] = getDirectQualifyingParameters(row)
    # prodQualifyingParams['IndirectQualifyingParameters'] = getIndirectQualifyingParameters(row)

    return prodQualifyingParams


def getDirectQualifyingParameters(row):
    directQualifyingParameters = OrderedDict()
    directQualifyingParameters['SequenceNumber'] = row['Sequence number111']
    directQualifyingParameters['ParameterId'] = row['Parameter ID']
    directQualifyingParameters['ParameterName'] = row['Parameter name']
    directQualifyingParameters['ParameterValueType'] = row['Type of parameter value']
    directQualifyingParameters['ParameterValue'] = row['Parameter value']

    return directQualifyingParameters


def getIndirectQualifyingParameters(row):
    inDirectQualifyingParameters = OrderedDict()
    inDirectQualifyingParameters['SequenceNumber'] = row['Sequence number1111']
    inDirectQualifyingParameters['ParameterId'] = row['Parameter ID1']
    inDirectQualifyingParameters['ParameterName'] = row['Parameter name1']
    inDirectQualifyingParameters['ParameterValueType'] = row['Type of parameter value1']
    inDirectQualifyingParameters['ParameterValue'] = row['Parameter value1']

    return inDirectQualifyingParameters


def getXmlDict():
    with open('input.csv', 'r', encoding='utf-8-sig') as inputFile:
        xmlDict = OrderedDict()

        reader = csv.DictReader(inputFile)
        firstRow = True
        for row in reader:
            if firstRow:
                xmlDict['SubmissionDate'] = row['Report issue date']
                xmlDict['DraftReportId'] = row['Draft report ID']
                xmlDict['ReportId'] = row['Report ID']
                xmlDict['ReportingPeriod'] = row['Reporting Period']
                xmlDict['Year'] = row['Year']
                xmlDict['TotalImported'] = row['Total goods imported']
                xmlDict['TotalEmissions'] = row['Total emissions']
                xmlDict['Declarant'] = getDeclarant(row)
                xmlDict['Importer'] = getImporter(row)
                xmlDict['NationalCompetentAuth'] = OrderedDict({"ReferenceNumber": row['Reference number']})
                xmlDict['Signatures'] = getSignatures(row)
                xmlDict['ImportedGood'] = list()
                firstRow = False

            if row['Goods item number'] == "":
                break

            xmlDict['ImportedGood'].append(getImportedGood(row))
        return xmlDict


if __name__ == '__main__':
    schema = xmlschema.XMLSchema('QReport_v17.00.xsd')
    root = OrderedDict()
    root["QReport"] = getXmlDict()
    xml = dicttoxml(root, root=False, attr_type=False, fold_list=False)
    dom = parseString(xml)
    formattedXml = dom.toprettyxml()
    formattedXmlFixed = (formattedXml
                         .replace("True", "true")
                         .replace("False", "false")
                         .replace("<QReport>", """<QReport xmlns="http://xmlns.ec.eu/BusinessObjects/CBAM/Types/V1">"""))

    with (open('output.xml', 'w')) as output:
        output.write(formattedXmlFixed)

    xmlHashMap = schema.to_dict('output.xml')
